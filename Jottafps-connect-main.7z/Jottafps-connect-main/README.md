# SWERVIN AUTOCONNECT

## REQUIRES

discord.js@13.8.1<br>colors<br>axios

*Não dou suporte para instalação!*

### [By Swervin Studios](https://discord.gg/W3n8N6mxbF)
